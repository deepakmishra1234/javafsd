// Projects
const container=document.getElementById("container");
const projects=document.querySelector(".project");
const projectHideBtn=document.querySelector(".project-hide-btn")



// project.addEventListener("mouseleave", () => {
// project.firstElementChild.style.top = "2rem";
//   });
  projects.addEventListener("click",()=>{
const bigImgWrapper=document.createElement("div")
bigImgWrapper.className="project-img-wrapper"
 container.appendChild(bigImgWrapper)

 const bigImg=document.createElement("img")
 //bigImg.className="project-img"
 bigImg.classList.add("project-img");
 const imgPath="images/dish1"
 bigImg.setAttribute("src",`${imgPath}.jpg`)
 bigImgWrapper.appendChild(bigImg);
 document.body.style.overflowY="hidden";

 projectHideBtn.classList.add("change")

 projectHideBtn.onclick=()=>{
projectHideBtn.classList.remove("change")
bigImgWrapper.remove();
document.body.style.overflowY="scroll";
 }
})
//end of big project img
// i>=6 && (project.style.cssText="display:none;opacity:0");
