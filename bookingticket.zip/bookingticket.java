package Class.practice;

import java.util.LinkedList;
import java.io.IOException;
import java.util.Scanner;

class Rows
{
	
	Scanner sc=new Scanner(System.in);
	LinkedList<String> last=new LinkedList<String>();
	
	void RowA(String manager,char Ch) throws IOException
	{  
		// choose the seats in Row A
		
		char check;
		String str;
		int prvamt=0;
		do {
			int count=0;
		LinkedList<String> A=new LinkedList<String>();
		System.out.println("user chosen seats in RowA"+last);
		System.out.println("How many seat are required by you:");
	
		int[] ch=new int[sc.nextInt()];
		if(ch.length<=10) {
		 System.out.println("Enter the seat number from(1-10)");
		 
		 for(int i=0;i<ch.length;i++) 
		 {
			  ch[i]=sc.nextInt();
			   
		 }
		 for(int a: ch)
		 {
			 if(a <=10 ) 
			 {
				 str=manager+" "+Ch+a;
				 if((last.contains(str))||A.contains(str)) 
				 {
					System.out.println("the tickets are booked ..... no need");
				 }
				 else 
				 {
				A.add(count,str);
				count++;
				 }
			 }
			 else 
			 {
                System.out.println(" entered invalid seat number");
			 }
		 }
		}
		 else 
		 {
			 throw new ArrayIndexOutOfBoundsException("You reached maximum limits of booking");
			}
		  last.addAll(A);
		 System.out.println("Your have selected:"+A);
		 prvamt+=count*200;
		 System.out.println("here is the bill sir :"+prvamt);
		 System.out.println("Do you want to book seat again(y/n):");
		 check=sc.next().charAt(0);
		}
		 while(check == 'Y' || check == 'y'); 
		 
	}
		 
	void RowB(String manager,char Ch)
	{    
		// choose the seats in row B
		char check;
		String str;
		int prvamt=0;
			int count=0;
			do
			{
		LinkedList<String> B=new LinkedList<String>();
		System.out.println("How many seats are required by you :");
		System.out.println("User chosen seats in RowB"+last);
		int[] ch=new int[sc.nextInt()];
		if(ch.length<=10)
		{
		 System.out.println("Enter the seat number from(1-10)");
		 
		 for(int i=0;i<ch.length;i++) 
		 {
			  ch[i]=sc.nextInt();
		 }
		 for(int a: ch) 
		 {
			 if(a <=10 )
			 {
				 str=manager+" "+Ch+a;
				 if(last.contains(str))
				 {
					System.out.println("the tickets are already booked......no need");
				 }
				 else 
				 {
				B.add(count,str);
				count++;
				 }
			 }
			 else
			 {
				 System.out.println(" Entered invalid seat number ");
			 }
		 }
		}
		 else
		 {
			 throw new ArrayIndexOutOfBoundsException("You reached maximum limit of booking");
			}
		 last.addAll(B);
		 System.out.println("Your have selected:"+B);
		 prvamt+=count*200;
		 System.out.println("Here is the total bill sir:"+prvamt);
		 System.out.println("Do you want to book seat again(y/n):");
		 check=sc.next().charAt(0);
			}
			while(check == 'Y' || check == 'y');

	}
	
	void RowC(String manager,char Ch)
	{
		//choose the seats in Row C 
		char check;
		String str;
		int prvamt=0;
		do {
			int count=0;
		LinkedList<String> C=new LinkedList<String>();
		System.out.println("How many seats are required by you:");
		System.out.println("User chosen seats in RowC"+last);
		int[] ch=new int[sc.nextInt()];
		if(ch.length<=10) 
		{
		 System.out.println("Enter the seat number from(1-10)");
		 
		 for(int i=0;i<ch.length;i++)
		 {
			  ch[i]=sc.nextInt();
		 }
		 for(int a: ch)
		 {
			 if(a <=10 )
			 {
				 str=manager+" "+Ch+a;
				 if(last.contains(str)) 
				 {
					System.out.println("Tickets are already booked....no need");
				 }
				 else
				 {
				C.add(count,str);
				count++;
				 }
			 }
			 else
			 {
				 System.out.println(" Entered invalids seat number ");
			 }
		 }
		}
		 else 
		 {
			 throw new ArrayIndexOutOfBoundsException("you reached the maximum limit of booking");
			}
		last.addAll(C);
		 System.out.println("Your have selected:"+C);
		 prvamt+=count*200;
		 System.out.println("Here is the total bill sir:"+prvamt);
		 System.out.println("Do you want to book seat again(y/n):");
		 check=sc.next().charAt(0);
	}
		while(check == 'Y' || check == 'y'); 

	}
	
	void RowD(String manager,char Ch)
	{
	 //choose the seats in RowD
		char check;
		String str;
		int prvamt=0;
		do {
			int count=0;
		LinkedList<String> D=new LinkedList<String>();
		System.out.println("How many seats are required by you :");
		System.out.println("User chosen seats in RowD"+last);
		int[] ch=new int[sc.nextInt()];
		if(ch.length<=10) 
				{
		 System.out.println("Enter the seat number from(1-10)");
		 
		 for(int i=0;i<ch.length;i++) 
		 {
			  ch[i]=sc.nextInt();
		 }
		 for(int a: ch) 
		 {
			 if(a <=10 )
			 {
				 str=manager+" "+Ch+a;
				 if(last.contains(str))
				 {
					System.out.println("the tickets are already booked.........no need");
				 }
				 else
				 {
				D.add(count,str);
				count++;
				 }
			 }
			 else 
			 {
				 System.out.println("Entered invalid seat number");
			 }
		 }
		}
		 else 
		 {
			 throw new ArrayIndexOutOfBoundsException("You have reached the maximum limit of booking");
			}
		last.addAll(D);
		 System.out.println("Your have selected:"+D);
		 prvamt+=count*200;
		 System.out.println("Here is the total bill sir:"+prvamt);
		 System.out.println("Do you want to book seat again(y/n):");
		 check=sc.next().charAt(0);
	}
		while(check == 'Y' || check== 'y'); 

		 
	}
	
	void RowE(String manager,char Ch)
	{          
		//choose seats in RowE
		char check;
		int prvamt=0;
		String str;
		do {
			int count=0;
		LinkedList<String> E=new LinkedList<String>();
		System.out.println("How many seats are required by you :");
		System.out.println("User chosen seats in RowE"+last);
		int[] ch=new int[sc.nextInt()];
		if(ch.length<=10) {
		 System.out.println("Enter the seat number from(1-10)");
		 
		 for(int i=0;i<ch.length;i++)
		 {
			  ch[i]=sc.nextInt();
		 }
			  for(int a: ch)
			  {
					 if(a <=10 )
					 {
						 str=manager+" "+Ch+a;
						 if(last.contains(str)) 
						 {
							System.out.println("tickets are already booked........no need");
						 }
						 else 
						 {
						E.add(count,str);
						count++;
						 } 
					 }
					 else {
						 System.out.println("Entered invalid seat number");
					 }
				 }
		}
		 else
		 {
			 throw new ArrayIndexOutOfBoundsException("You reached maximum booking limit");
			}
		last.addAll(E);
		 System.out.println("Your have selected:"+E);
		 prvamt+=count*200;
		 System.out.println("Here is the total bill sir:"+prvamt);
		 System.out.println("Do you want to book seat again(y/n):");
		 check=sc.next().charAt(0);
	}
		while(check == 'Y' || check == 'y'); 

	}
	
	void RowF(String manager,char Ch)
	{
		//choose seats F row
		char check;
		String str;
		int prvamt=0;
		do 
		{
			int count=0;
		LinkedList<String> F=new LinkedList<String>();
		System.out.println("How many seats are required by you :");
		System.out.println("User chosen seats in RowF"+last);
		int[] ch=new int[sc.nextInt()];
		if(ch.length<=10) 
		{
		
		 System.out.println("Enter the seat number from(1-10)");
		 
		 for(int i=0;i<ch.length;i++) 
		 {
			  ch[i]=sc.nextInt();
		 }
		 for(int a: ch)
		 {
			 if(a <=10 )
			 {
				 str=manager+" "+Ch+a;
				 if(last.contains(str)) 
				 {
					System.out.println("The tickets are already booked........no need");
				 }
				 else 
				 {
				F.add(count,str);
				count++;
				 }
			 }
			 else 
			 {
				 System.out.println("You have entered invalid seat number");
			 }
		 }
		}
		else 
		{
			 throw new ArrayIndexOutOfBoundsException("You have reached the maximum limit of booking");
		}
		last.addAll(F);
		 System.out.println("Your have selected:"+F);
		 prvamt+=count*200;
		 System.out.println("Here isthe total bill sir:"+prvamt);
		 System.out.println("Do you want to book seat again(y/n):");
		 check=sc.next().charAt(0);
		}
		while(check == 'Y' || check == 'y'); 
 
	}
	
}
 class Row extends Rows
 {
	 Rows rs=new Rows();
	  Scanner sc=new Scanner(System.in);
	  
	  void Row(String User) 
	  {  
		  //choose row in  the movie theater
			 System.out.println("Choose the  Row accordin to wish (A-F):");
	         System.out.println("A. Row-A");
	         System.out.println("B. Row-B");
	         System.out.println("C. Row-C");
	         System.out.println("D. Row-D");
	         System.out.println("E. Row-E");
	         System.out.println("F. Row-F");
	        
	        String st=sc.next().toUpperCase();
	        char ch=st.charAt(0);  //  
	        System.out.println("Your have chosen Row-"+ch);
	        seatupdate(ch,User);
	   
		 } 
	  
	  void seatupdate(char choice,String User) {
			 switch(choice) 
			 {                             //to call row in theater
			 case 'A':
				 try {
				 rs.RowA(User,choice);
				 }
				 catch(Exception e) {e.getMessage();}
				 break;
			 case 'B':
				 try
				 {
					 rs.RowB(User,choice);
					 }
				 catch(Exception e) {e.getMessage();}
				 break;
			 case'C':
				 try {
					 rs.RowC(User,choice);
					 }
				 catch(Exception e) {e.getMessage();}
				 break;
			 case 'D':
				 try {
					 rs.RowD(User,choice);
					 }
				 catch(Exception e) {e.getMessage();}
				 break;
			 case 'E':
				 try {
					 rs.RowE(User,choice);
					 }
				 catch(Exception e) {e.getMessage();}
				 break;
			 case 'F':
				 try {
					 rs.RowF(User,choice);
					 }
				 catch(Exception e) {e.getMessage();}
				 break;
				 
		     default:
			     System.out.println("Entered invalid value");
			     Row(User);
			     break;
			 }
	  }	  
	  
  }
 
public class bookingticket extends Row{
	
		    Scanner sc=new Scanner(System.in); 
	 void booking(String User)
	 {   
		 // Movie ticket booking
		 
         System.out.println("Choose the  slot for show:");
         System.out.println("1. 9am-12pm");
         System.out.println("2. 1pm-4pm");
         System.out.println("3. 5pm-8pm");
         System.out.println("4. 9pm-12pm");
         System.out.println("5. 1am-4am");
         System.out.println("6. 5am-8am");
        int choice=sc.nextInt();
		 switch(choice) {
		 case 1:
			 System.out.println(" the time slot chosen is 9am-12pm");
			 Row(User);
			 break;
		 case 2:
			 System.out.println("the time slot chosen is 1pm-4pm");
			 Row(User);
			 break;
		 case 3:
			 System.out.println("the time slot chosen is 5pm-8pm");
			 Row(User);
			 break;
		 case 4:
			 System.out.println("the time slot chosen is 9pm-12pm");
			 Row(User);
			 break;
		 case 5:
			 System.out.println("the time slot chosen is 1am-4am");
			 Row(User);
			 break;
		 case 6:
			 System.out.println("the time slot chosen is 5am-8am");
			 Row(User);
			 break;
			 
	     default:
		     System.out.println("Entered invalid value.... default value");
		     break;
		 }
	 }

	public static void main(String[] args) 
	{
		// In order to make feel good and comfortable the customer
		
		System.out.println(">>>>.***********>>>>>>>>............***********");
		System.out.println("Welcome to the Cinema ...... The PVR show");
		System.out.println(" Select the movie with  wished show slots.... available");
		System.out.println("Book the tickets ....and enjoy....fully");
		
		bookingticket book=new bookingticket();
		Scanner sc=new Scanner(System.in);
		LinkedList<String> li=new LinkedList<String>();

	    li.add("sameer@thor.com");
	    li.add("sameer123@");
	    li.add("rahul@cap.com");
	    li.add("rahul1234*");
	    li.add("sohel@jh.com");
	    li.add("soelblackhorse123#");
	    li.add("shreya@sw.com");
	    li.add("shreya786%");
	    li.add("praharsh@vir.com");
	    li.add("praharsh123&");
	    
	    System.out.println("Asking....  are you a user or admin?(y/n)");
	    String str=sc.nextLine();

	    if(str.charAt(0)=='Y' || str.charAt(0)=='y') 
	    {
	    	
	       	System.out.println("Kindly give your user name and password:");
			String user=sc.nextLine();
			String pass=sc.nextLine();
			
			for(int i=0;i<li.size();i=i+2) 
			{
				if((li.contains(user)) && (li.contains(pass)))
				{  
					//checking the user's validation
					int indx=li.indexOf(user);
					System.out.println("Do you want to upadte password?(y/n)");
		       		String upt=sc.nextLine();
		       		if(upt.charAt(0)=='Y' || upt.charAt(0)=='y') {  //to update password
		       			System.out.println("Enter your Old password:");
		       	 		String old=sc.nextLine();
		       	 		System.out.println("Enter your New password:");
		       	 		String ne=sc.nextLine();
		       	 		li.set(indx+1,ne);
		       	 		System.out.println("password updated");
		       	 		System.out.println("Do you want to book tickets?(y/n)");
		       	 		char ch=sc.next().charAt(0);
		       	 		if(ch == 'Y' || ch == 'y') {
		       	 		book.booking(user);
		       	 		}
		       	 		else {
		       	 			System.out.println("thanks for visiting and visit gain ");
		       	 		}
		       		}
		       		else {
		       			book.booking(user);
		       		}	
			}
				else {
					System.out.println("Soory sir you are not allowed .... sorrow for incovenience");
				}
       	}
       }else {
    	   System.out.println("Your not allowed do actions");
       }
	    sc.close();
	}

}


